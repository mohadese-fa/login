from django.contrib import admin
from .models import *
# Register your models here.
admin.site.register(contactClass)
admin.site.register(staticContentClass)
admin.site.register(categoryClass)
admin.site.register(brandClass)
admin.site.register(productClass)
admin.site.register(colorClass)
admin.site.register(sizeClass)
admin.site.register(productVariantClass)
admin.site.register(agencyClass)
admin.site.register(questionClass)
admin.site.register(questionBClass)
admin.site.register(questionCClass)
admin.site.register(questionDClass)
admin.site.register(staticPhotoClass)
admin.site.register(cityClass)
admin.site.register(productImagesClass)
